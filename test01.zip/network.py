import re
import sys

class IP:

	def __init__(self,ip_str,mask_str=None):
		if mask_str is None:
			ip_pattern=r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
			if re.fullmatch(ip_pattern,ip_str):
				ip_str+='/32'
			if not IP.is_legal_ip(ip_str):
				print('illegal ip:'+ip_str)
				sys.exit()
			word=ip_str.split('/')
			self.ip_bit=IP.str2bit(word[0])
			self.mask_bit=IP.mask_length2bit(int(word[1]))
		else:
			if not IP.is_legal_ip(ip_str+'/32'):
				print('illegal ip:'+ip_str)
				sys.exit()
			if not IP.is_legal_ip(mask_str+'/32'):
				print('illegal mask:'+mask_str)
				sys.exit()
			self.ip_bit=IP.str2bit(ip_str)
			self.mask_bit=IP.str2bit(mask_str)

	@staticmethod
	def is_legal_ip(cur_ip):
		regular_ip_pattern=r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}'
		if not re.fullmatch(regular_ip_pattern,cur_ip):
			return False
		word=cur_ip.split('/')
		octet_list=word[0].split('.')
		if int(octet_list[0])<0 or int(octet_list[0])>255:
			return False
		if int(octet_list[1])<0 or int(octet_list[1])>255:
			return False
		if int(octet_list[2])<0 or int(octet_list[2])>255:
			return False
		if int(octet_list[3])<0 or int(octet_list[3])>255:
			return False
		if int(word[1])<0 or int(word[1])>32:
			return False
		return True

	@staticmethod
	def str2bit(cur_str):
		octet_list=cur_str.split('.')
		ip_bit=int(octet_list[0])
		ip_bit=ip_bit<<8
		ip_bit=ip_bit|int(octet_list[1])
		ip_bit=ip_bit<<8
		ip_bit=ip_bit|int(octet_list[2])
		ip_bit=ip_bit<<8
		ip_bit=ip_bit|int(octet_list[3])
		
		return ip_bit
	
	@staticmethod
	def bit2str(cur_bit):
		octet_bit=0b11111111
		ip_str='.'+str(cur_bit&octet_bit)
		cur_bit=cur_bit>>8
		ip_str='.'+str(cur_bit&octet_bit)+ip_str
		cur_bit=cur_bit>>8
		ip_str='.'+str(cur_bit&octet_bit)+ip_str
		cur_bit=cur_bit>>8
		ip_str=str(cur_bit&octet_bit)+ip_str
		
		return ip_str

	@staticmethod
	def mask_length2bit(cur_length):
		mask_bit=0
		for count in range(31):
			if cur_length>count:
				mask_bit=mask_bit|1
			mask_bit=mask_bit<<1
		if cur_length==32:
			mask_bit=mask_bit|1
		
		return mask_bit

	@staticmethod
	def bit2mask_length(cur_bit):
		mask_length=0
		for count in range(31):
			if cur_bit&1==1:
				mask_length+=1
			cur_bit=cur_bit>>1
		if cur_bit&1==1:
			mask_length+=1
		
		return mask_length

	def get_ip_str(self):
		return self.bit2str(self.ip_bit)

	def get_mask_str(self):
		return self.bit2str(self.mask_bit)

	def get_address_str(self):
		ip_str=self.bit2mask_length(self.ip_bit)
		mask_length=self.bit2mask_length(self.mask_bit)
		address_str=ip_str+'/'+str(mask_length)
		
		return address_str

	def get_network_bit(self):
		return self.ip_bit&self.mask_bit
	
	def get_network_address(self):
		return IP.bit2str(get_network_bit())

	def get_broadcast_bit(self):
		return self.ip_bit|self.mask_bit

	def get_broadcast_address(self):
		return IP.bit2str(get_broadcast_bit)

	def contains_ip(self,search_ip):
		if self.get_network_bit()<=search_ip.get_network_bit() and self.get_broadcast_bit()>=search_ip.get_broadcast_bit():
			return True
		else:
			return False

class AclSearch:
	
	def __init__(self,src_ip,dst_ip,dst_protocol,dst_service):
		self.src_ip=src_ip
		self.dst_ip=dst_ip
		self.dst_protocol=dst_protocol
		self.dst_service=dst_service

	def get_src_ip(self):
		return self.src_ip

	def get_dst_ip(self):
		return self.dst_ip

	def get_dst_protocol(self):
		return self.dst_protocol

	def get_dst_service(self):
		return self.dst_service

	def show_all():
		print(self.src_ip)
		print(self.dst_ip)
		print(self.dst_service)
		print(self.dst_port)
