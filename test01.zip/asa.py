import sys
import re
import network

class ObjectGroup:
	def __init__(self,group,name):
		self.group=group
		self.name=name
		self.child_list=[]

	def get_group(self):
		return self.group

	def get_name(self):
		return self.name

	def get_child_list(self):
		return self.child_list

	def append(self,line):
		self.child_list.append(line)

	def contains_ip(self,search_ip):
		go_pattern=r' group-object .*\n'
		re_go=re.compile(go_pattern)
		no_pattern=r' network-object .*\n'
		re_no=re.compile(no_pattern)
		
		for cur_obj_str in self.child_list:
			#print(cur_obj_str)
			if re_go.fullmatch(cur_obj_str):
				#print(cur_obj_str)
				cur_child_str=cur_obj_str
				cur_child_str=re.sub(' group-object ','',cur_child_str)
				cur_child_str=re.sub('\n','',cur_child_str)
				cur_child=ObjectGroup.og_dic.get(cur_child_str)
				if cur_child.contains_ip(search_ip):
					return True
			elif re_no.fullmatch(cur_obj_str):
				word=cur_obj_str.split()
				#print(word[0])
				if word[1]=='host':
					cur_ip=network.IP(word[2])
				else:
					cur_ip=network.IP(word[1],word[2])
				if cur_ip.contains_ip(search_ip):
					return True
			else:
				print('child exception:'+cur_obj)
				sys.exit()
		return False

	@classmethod
	def set_og_dic(cls,og_dic):
		cls.og_dic=og_dic

	def show_all(self):
		print(self.name)
		print(self.group)
		for child in self.child_list:
			print(child)

class AccessList:
	def __init__(self,line,name,permit_bool,protocol,src_ip,src_port,dst_ip,dst_port,log_bool):
		self.line=line
		self.name=name
		self.permit_bool=permit_bool
		self.protocol=protocol
		self.src_ip=src_ip
		self.src_port=src_port
		self.dst_ip=dst_ip
		self.dst_port=dst_port
		self.log_bool=log_bool

	def get_line(self):
		return self.line

	def get_name(self):
		return self.name

	def is_permited(self):
		return self.permit_bool

	def get_protocol(self):
		return self.protocol

	def get_src_ip(self):
		return self.src_ip

	def get_src_port(self):
		return self.src_port

	def get_dst_ip(self):
		return self.dst_ip

	def get_dst_port(self):
		return self.dst_port

	def contains_src_ip(self,search_src_ip):
		og_pattern=r'object-group .*'
		re_og=re.compile(og_pattern)
		
		search_src_ip_obj=network.IP(search_src_ip)
		if re_og.match(self.src_ip):
			#print(self.src_ip)
			root_obj_grp_str=self.src_ip
			root_obj_grp_str=re.sub('object-group ','',root_obj_grp_str)
			root_obj_grp=ObjectGroup.og_dic.get(root_obj_grp_str)
			#root_obj_grp.show_all()
			search_src_ip_obj=network.IP(search_src_ip)
			return root_obj_grp.contains_ip(search_src_ip_obj)
		elif self.src_ip=='any':
			return True
		else:
			print('src_ip excepiton:'+self.src_ip)
			sys.exit()

	def contains_dst_ip(self,search_dst_ip):
		og_pattern=r'object-group .*'
		re_og=re.compile(og_pattern)
		
		search_dst_ip_obj=network.IP(search_dst_ip)
		if re_og.match(self.dst_ip):
			#print(self.dst_ip)
			root_obj_grp_str=self.dst_ip
			root_obj_grp_str=re.sub('object-group ','',root_obj_grp_str)
			root_obj_grp=ObjectGroup.og_dic.get(root_obj_grp_str)
			#root_obj_grp.show_all()
			search_dst_ip_obj=network.IP(search_dst_ip)
			return root_obj_grp.contains_ip(search_dst_ip_obj)
		elif self.dst_ip=='any':
			return True
		else:
			print('dst_ip excepiton:'+self.dst_ip)
			sys.exit()

	def contains_dst_port(self,search_protocol,search_service):
		#print(self.service)
		eq_pattern=r'eq .*'
		re_eq=re.compile(eq_pattern)
		og_pattern=r'object-group .*'
		re_og=re.compile(og_pattern)
		po_pattern=r' port-object eq .*'
		re_po=re.compile(po_pattern)
		
		if self.dst_port=='':
			return True
		elif re_eq.match(self.dst_port):
			#print(self.protocol+','+self.dst_port)
			tmp_port=self.dst_port
			tmp_port=re.sub('eq ','',tmp_port)
			tmp_port=re.sub(' $','',tmp_port)
			cur_service=AccessList.get_cisco_port_num(self.protocol,tmp_port)
			if self.protocol==search_protocol and cur_service==search_service:
				#print(self.protocol+','+self.service+','+search_service)
				return True
			else:
				return False
		elif re_og.match(self.dst_port):
			cur_og_name=self.dst_port
			cur_og_name=re.sub('object-group ','',cur_og_name)
			cur_og_name=re.sub(' $','',cur_og_name)
			#print(cur_og_name+'%%%')
			cur_og=AccessList.og_dic.get(cur_og_name)
			#cur_og.show_all()
			#sys.exit()
			if cur_og.get_group()!='service':
				print('exception:'+cur_og.get_group())
				sys.exit()
			for cur_service in cur_og.get_child_list():
				#print(cur_service)
				if re_po.match(cur_service):
					cur_service=re.sub(' port-object eq ','',cur_service)
					cur_service=re.sub('\n','',cur_service)
					cur_protocol=self.protocol
					cur_protocol=re.sub('object-group ','',cur_protocol)
					cur_service=AccessList.get_cisco_port_num(cur_protocol,cur_service)
					#print(cur_service+'%%%')
					if cur_protocol==search_protocol and cur_service==search_service:
						#print(self.protocol+','+self.service+','+search_service)
						return True
			return False
		else:
			print('exception:'+self.dst_port)
			sys.exit()

	@staticmethod
	def get_cisco_port_num(protocol,service):
		digit_pattern=r'\d+'
		re_digit=re.compile(digit_pattern)
		
		if protocol=='tcp':
			if re_digit.fullmatch(service):
				return service
			elif service=='ftp':
				return '21'
			elif service=='ssh':
				return '22'
			elif service=='telnet':
				return '23'
			elif service=='www':
				return '80'
			elif service=='https':
				return '443'
			else:
				print('tcp exception:'+service)
				sys.exit()
		elif protocol=='udp':
			if re_digit.fullmatch(service):
				return service
			elif service=='ntp':
				return '123'
			elif service=='snmp':
				return '161'
			elif service=='snmptrap':
				return '162'
			elif service=='syslog':
				return '514'
			else:
				print('udp exception:'+service)
				sys.exit()
		elif protocol=='tcp-udp':
			if re_digit.fullmatch(service):
				return service
			elif service=='domain':
				return '53'
			else:
				print('tcp-udp exception:'+service)
				sys.exit()
		else:
			print('protocol exception:'+protocol)
			sys.exit()

	def show_all(self):
		print(self.name)
		print(self.permit_bool)
		print(self.protocol)
		print(self.src_ip)
		print(self.src_port)
		print(self.dst_ip)
		print(self.dst_port)
		print(self.log_bool)
		print()
