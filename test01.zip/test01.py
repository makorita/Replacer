import glob
import re
import asa
import sys
import network

def get_run_list(file_name):
	start_pattern=r': Saved'
	re_start=re.compile(start_pattern)
	end_pattern=r'Cryptochecksum:.*'
	re_end=re.compile(end_pattern)
	
	with open(file_name) as file:
		list=file.readlines()
	start_num=-1
	end_num=-1
	for count, line in enumerate(list):
		if re_start.match(line):
			start_num=count
		if start_num>-1 and re_end.match(line):
			end_num=count
			break
	run_list=list[start_num:end_num+1]
	'''
	for line in run_list:
		print(type(line))
		print('debug:'+line)
	'''
	
	return run_list

def get_og_dic(run_list):
	og_dic={}
	og_pattern=r'object-group .*'
	re_og=re.compile(og_pattern)
	child_pattern=r' .*'
	re_child=re.compile(child_pattern)
	
	mode='OUT'
	for line in run_list:
		if mode=='IN' and not re_child.match(line):
			mode='OUT'
		if mode=='OUT' and re_og.match(line):
			word=line.split()
			cur_object_group=asa.ObjectGroup(word[1],word[2])
			og_dic[cur_object_group.get_name()]=cur_object_group
			mode='IN'
		elif mode=='IN' and re_child.match(line):
			cur_object_group.append(line)
	
	return og_dic

def get_acl_list(run_list):
	acl_list=[]
	acl_pattern=r'access-list .*'
	re_acl_pattern=re.compile(acl_pattern)
	detail_pattern=r'access-list (.+) extended (permit|deny) (ip|icmp|tcp|udp|object-group .+?) (object-group .+?|any) (range \d+ \d+ )*(object-group .+?|any) (eq .+? |object-group .+?)*(log )*\n'
	re_detail_pattern=re.compile(detail_pattern)
	remark_pattern=r'access-list .+ remark .+'
	re_remark_pattern=re.compile(remark_pattern)
	kakko_pattern=r'(.+)'
	re_kakko_pattern=re.compile(kakko_pattern)
	
	for line in run_list:
		#print(type(line))
		#print('debug:'+line)
		if not re_acl_pattern.match(line):
			continue
		if re_remark_pattern.match(line):
			continue
		
		if re_detail_pattern.fullmatch(line):
			result=re_detail_pattern.search(line)
			#for count in range(8):
			#	print(result.group(count+1))
			name=result.group(1)
			if result.group(2)=='permit':
				permit_bool=True
			else:
				permit_bool=False
			protocol=result.group(3)
			src_ip=result.group(4)
			if not result.group(5) is None:
				src_port=result.group(5)
			else:
				src_port=''
			dst_ip=result.group(6)
			if not result.group(7) is None:
				dst_port=result.group(7)
			else:
				dst_port=''
			if result.group(8)=='log ':
				log_bool=True
			else:
				log_bool=False
			cur_acl=asa.AccessList(line,name,permit_bool,protocol,src_ip,src_port,dst_ip,dst_port,log_bool)
			#cur_acl.show_all()
			acl_list.append(cur_acl)
		else:
			print('unmatch:'+line)
			sys.exit()
	
	return acl_list

def get_kosya_name(ip_str):
	first_pos=ip_str.find('.')
	second_pos=ip_str.find('.')

def is_permited(cur_search_acl,acl_name,og_dic,acl_list):
	for cur_acl in acl_list:
		if cur_acl.get_name()!=acl_name:
			continue
		if not cur_acl.is_permited():
			continue
		if cur_search_acl.get_dst_protocol()!=cur_acl.get_protocol() and cur_acl.get_protocol()!='ip':
			continue
		
		if not cur_acl.contains_dst_port(cur_search_acl.get_dst_protocol(),cur_search_acl.get_dst_service()):
			continue
		print('dst_port contains')
		if not cur_acl.contains_dst_ip(cur_search_acl.get_dst_ip()):
			continue
		print('dst_ip contains')
		if not cur_acl.contains_src_ip(cur_search_acl.get_src_ip()):
			continue
		print('src_ip contains')
		print(cur_acl.get_line())
		


#処理開始
file_path='EJNRYPFW01_act_20161020.txt'
file_path='EJNROBFW01_act_20161013.txt'
#acl_name='acl-in_EJUP_F'
acl_name='acl-in_EJUB_F'

#src_ip='172.16.3.176/28'
src_ip='172.16.20.1/28'
#dst_ip='192.168.0.1/26'
dst_ip='10.0.0.1/32'
dst_protocol='tcp'
dst_service='80'
cur_search_acl=network.AclSearch(src_ip,dst_ip,dst_protocol,dst_service)



print(file_path)
run_list=get_run_list(file_path)
og_dic=get_og_dic(run_list)
acl_list=get_acl_list(run_list)
asa.ObjectGroup.set_og_dic(og_dic)

is_permited(cur_search_acl,acl_name,og_dic,acl_list)

'''
fw_pattern=r'.*EJ.*FW.*'
files = glob.glob("./*")
for file in files:
	if not re.match(fw_pattern,file):
		continue
	
	print(file)
	run_list=get_run_list(file)
	og_dic=get_og_dic(run_list)
	acl_list=get_acl_list(run_list)
	asa.ObjectGroup.set_og_dic(og_dic)

	is_permited(cur_search_acl,acl_name,og_dic,acl_list)
	#break
'''
