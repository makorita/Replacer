import re
import sys

class IP:

	def __init__(self,ip_str):
		ip_pattern=r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
		if re.fullmatch(ip_pattern,ip_str):
			ip_str+='/32'
		if not IP.is_legal_ip(ip_str):
			print('illegal ip:'+ip_str)
			sys.exit()
		
		word=ip_str.split('/')
		octet_list=word[0].split('.')
		ip_bit=int(octet_list[0])
		ip_bit=ip_bit<<8
		ip_bit=ip_bit|int(octet_list[1])
		ip_bit=ip_bit<<8
		ip_bit=ip_bit|int(octet_list[2])
		ip_bit=ip_bit<<8
		ip_bit=ip_bit|int(octet_list[3])
		self.ip_bit=ip_bit
		
		mask_bit=0
		for count in range(31):
			if int(word[1])>count:
				mask_bit=mask_bit|1
			mask_bit=mask_bit<<1
		if int(word[1])==32:
			mask_bit=mask_bit|1
		self.mask_bit=mask_bit
	
	@staticmethod
	def is_legal_ip(cur_ip):
		regular_ip_pattern=r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2}'
		if not re.fullmatch(regular_ip_pattern,cur_ip):
			return False
		word=cur_ip.split('/')
		octet_list=word[0].split('.')
		if int(octet_list[0])<0 or int(octet_list[0])>255:
			return False
		if int(octet_list[1])<0 or int(octet_list[1])>255:
			return False
		if int(octet_list[2])<0 or int(octet_list[2])>255:
			return False
		if int(octet_list[3])<0 or int(octet_list[3])>255:
			return False
		if int(word[1])<0 or int(word[1])>32:
			return False
		return True

	@staticmethod
	def bit2str(cur_bit):
		octet_bit=0b11111111
		ip_str='.'+str(cur_bit&octet_bit)
		cur_bit=cur_bit>>8
		ip_str='.'+str(cur_bit&octet_bit)+ip_str
		cur_bit=cur_bit>>8
		ip_str='.'+str(cur_bit&octet_bit)+ip_str
		cur_bit=cur_bit>>8
		ip_str=str(cur_bit&octet_bit)+ip_str
		
		return ip_str

	@staticmethod
	def bit2mask_length(cur_bit):
		mask_length=0
		for count in range(31):
			if cur_bit&1==1:
				mask_length+=1
			cur_bit=cur_bit>>1
		if cur_bit&1==1:
			mask_length+=1
		
		return mask_length

	def get_ip_str(self):
		return self.bit2str(self.ip_bit)

	def get_mask_str(self):
		return self.bit2str(self.mask_bit)

	def get_address_str(self):
		ip_str=self.bit2mask_length(self.ip_bit)
		mask_length=self.bit2mask_length(self.mask_bit)
		address_str=ip_str+'/'+str(mask_length)
		
		return address_str

	def get_network_bit(self):
		return self.ip_bit&self.mask_bit
	
	def get_network_address(self):
		return IP.bit2str(get_network_bit())

	def get_broadcast_bit(self):
		return self.ip_bit|self.mask_bit

	def get_broadcast_address(self):
		return IP.bit2str(get_broadcast_bit)

	def contains_ip(self,search_ip):
		if self.get_network_bit()<=search_ip.get_network_bit() and self.get_broadcast_bit()>=search_ip.get_broadcast_bit():
			return True
		else:
			return False

class AclSearch:
	
	def __init__(self,src_ip,dst_ip,dst_protocol,dst_service):
		self.src_ip=src_ip
		self.dst_ip=dst_ip
		self.dst_protocol=dst_protocol
		self.dst_service=dst_service

	def get_dst_ip(self):
		return self.dst_ip

	def get_dst_protocol(self):
		return self.dst_protocol

	def get_dst_service(self):
		return self.dst_service

	def show_all():
		print(self.src_ip)
		print(self.dst_ip)
		print(self.dst_service)
		print(self.dst_port)
